<?php
/*
* -------------------------------------------------------------------------------------
* @author: EasTheme Team
* @author URI: https://eastheme.com
* @copyright: (c) 2020 EasTheme. All rights reserved
* -------------------------------------------------------------------------------------
*
* @since 1.0.1
*
*/

/* Exit if accessed directly */
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

class East_Widget_HotManga extends WP_Widget {

	function __construct() {

		$widget_ops = array('classname' => 'hotmanga_widget', 'description' => __d('Display Hot Manga') );
		$control_ops = array('width' => 300, 'height' => 350, 'id_base' => 'tpw_hotmanga');
		parent::__construct('tpw_hotmanga', __d('EasTheme - Hot Manga'), $widget_ops, $control_ops );

	}


	public function widget($args, $instance) {
		echo $args['before_widget'];
		if (!empty($instance['title'])) {
			echo $args['before_title'] . apply_filters('widget_title', $instance['title']) . '<div class="nav_items_module"><a class="btn prevf"><i class="fa fa-caret-left"></i></a><a class="btn nextf"><i class="fa fa-caret-right"></i></a></div>'. $args['after_title'];
		}
		$stripped = str_replace(' ', '', $instance['title']);
		$slider = strtolower($stripped);
		?>
		<div id="<?php echo $slider; ?>" class="load_slider flashit" style="display: block;">Loading..</div>

		<div class="relat widget-post slidfer <?php echo $slider; ?>">

			<?php
			$myposts = array(
				'showposts' => $instance['count'],
				'post_type' => 'manga',
				'meta_key' => 'east_hot',
				'meta_value' => 1
			);
			$wp_query = new WP_Query($myposts);
			while ($wp_query->have_posts()):
				$wp_query->the_post();?>
				<div class="animepost">
					<div class="animposx">
						<a rel="<?php the_ID();?>" href="<?php the_permalink();?>" title="<?php the_title();?>" alt="<?php the_title();?>">
							<div class="content-thumb">
								<div class="ply">
					      <i class="fas fa-book-open"></i>
									</div>
								   <?php echo the_thumbnail(get_the_ID(), '150','210' ); ?>
									 <div class="type <?php echo meta(get_the_ID(), 'east_type'); ?>"><?php echo meta(get_the_ID(), 'east_type'); ?></div>

								</div>
									<div class="data">
								<div class="title"> <?php the_title();?></div>
								<div class="score"><i class="fa fa-star"></i> <?php echo meta(get_the_ID(), 'east_score'); ?></div>
								<div class="type"><?php  echo status_manga(get_the_ID()); ?></div>
									</div>
							</a>
						</div>
					</div>
					<?php endwhile; ?>
				</div>

				<script type="text/javascript">
				$(document).ready(function()
				{

				$('.<?php echo $slider; ?>').owlCarousel({
				    loop:true,
				    dots: false,
				    autoplay:false,
				    pagination: false,
				    responsive:{
				      0:{
				        items:2,
				        nav:false,
				      },
				      600:{
				        items:4,
				        nav:false,
				      },
				      800:{
				        items:4,
				        nav:false,
				      },
				      1000:{
				        items:5,
				        nav:false,
				      }
				    }

				});
				var owl = $('.<?php echo $slider; ?>');
				owl.owlCarousel();
				// Go to the next item
				$('.nextf').click(function() {
				    owl.trigger('next.owl.carousel');
				})
				// Go to the previous item
				$('.prevf').click(function() {
				    // With optional speed parameter
				    // Parameters has to be in square bracket '[]'
				    owl.trigger('prev.owl.carousel', [300]);
				});
				});

				$.each(["#<?php echo $slider; ?>"], function(e, s) {
		        1 <= $(s).length && ($("#content").ready(function() {
		            $(s).css("display", "none")
		        }), $(".content").load(function() {
		            $(s).css("display", "none")
		        }))
		    });

				</script>

				<?php
				echo $args['after_widget'];
			}


				public function update($new_instance, $old_instance) {
					$instance = array();
					$instance['title'] = (!empty($new_instance['title'])) ? sanitize_text_field($new_instance['title']) : '';
					$instance['count'] = (!empty($new_instance['count'])) ? sanitize_text_field($new_instance['count']) : '';

					return $instance;
				}

	public function form($instance) {
		$defaults = array('title' => 'Hot Manga', 'count' => '10',  'orderby' => 'rand', 'status' => 'all', 'type' => 'all' , 'genre' => 'all', 'season' => 'all');
		$instance = wp_parse_args( (array) $instance, $defaults );

		?>
		<p>
	   <label for="<?php echo esc_attr($this->get_field_id('title')); ?>"><?php esc_attr_e('Title:', 'text_domain');?></label>
	   <input class="widefat" id="<?php echo esc_attr($this->get_field_id('title')); ?>" name="<?php echo esc_attr($this->get_field_name('title')); ?>" type="text" value="<?php echo $instance['title']; ?>">
		 	</p>
			<p>
	   <label for="<?php echo esc_attr($this->get_field_id('count')); ?>"><?php esc_attr_e('Count:', 'text_domain');?></label>
	   <input class="widefat" id="<?php echo esc_attr($this->get_field_id('count')); ?>" name="<?php echo esc_attr($this->get_field_name('count')); ?>" type="number" value="<?php echo $instance['count']; ?>">
		 	</p>

		<?php
	}


}

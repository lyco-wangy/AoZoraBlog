<?php
/*
* -------------------------------------------------------------------------------------
* @author: EasTheme
* @author URI: https://eastheme.com
* @copyright: (c) 2019 EasTheme. All rights reserved
* -------------------------------------------------------------------------------------
*
* @since 1.0.1
*
*/

/* Exit if accessed directly */
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

get_header();

$member = get_option('membersystem');
$recom = get_option('recommendedanime');
$japanese = meta( get_the_ID(), 'east_japanese' );
$synonyms = meta( get_the_ID(), 'east_synonyms' );
$english = meta( get_the_ID(), 'east_english' );
$serialization = meta( get_the_ID(), 'east_serialization' );
$totalch = meta( get_the_ID(), 'east_totalchapter' );
?>
<article id="post-<?php the_ID();?>" <?php post_class();?> itemscope="itemscope" itemtype="http://schema.org/CreativeWorkSeries">
   <div id="container">
      <div id="infoarea">
         <div class="post-body">
            <div class="infoanime widget_senction">
               <div class="thumb" itemprop="image" itemscope="" itemtype="https://schema.org/ImageObject">
								  <?php hot_label(get_the_ID()); ?>
                  <?php echo the_thumbnail(get_the_ID(), '205','282' ); ?>
                  <div class="rt">
                     <div class="rating-area">
                        <?php echo star_archive(get_the_ID(),3); ?>
                     </div>
                     <?php east_favorites_button(get_the_ID()); ?>
                  </div>
               </div>
               <div class="infox">
                  <h1 class="entry-title" itemprop="name"><i class="fas fa-book-open"></i> <?php the_title(); ?></h1>
                  <div class="desc">
                     <div class="entry-content entry-content-single" itemprop="description">
                        <?php if ( have_posts() ) :  while ( have_posts() ) : the_post(); the_content(); ?>
                     </div>
                  </div>
                  <div class="genre-info">
                     <?php tax_genres(get_the_ID()); ?>
                  </div>
               </div>
            </div>
						<div class="sharesection">
							 <center>
									<b><?php _d('Share to your friends!');?></b>
									<?php east_social_share(get_the_ID());?>
							 </center>
						</div>
						  <?php get_ads('adsbottomcover'); ?>
            <div class="anim-senct">
               <?php get_ads('adstopinfo','ads_info'); ?>
               <div class="right-senc widget_senction">
                  <div class="anime infoanime">
                     <div class="infox">
                        <h3 class="anim-detail">Manga Detail</h3>
                        <div class="spe">
                           <?php if($japanese){ ?><span><b>Japanese</b> <?php echo $japanese; ?></span><?php } ?>
                           <?php if($synonyms){ ?><span><b>Synonyms</b> <?php echo $synonyms; ?></span><?php } ?>
                           <?php if($english){ ?><span><b>English</b> <?php echo $english; ?></span><?php } ?>
                           <span><b>Status</b> <?php echo status_manga(get_the_ID()); ?></span>
                           <span><b>Type</b> <?php echo meta(get_the_ID(),'east_type'); ?></span>
                           <span><b>Author</b> <?php echo meta(get_the_ID(),'east_author'); ?></span>
                           <?php if($serialization){ ?><span><b>Serialization</b> <?php echo $serialization; ?></span><?php } ?>
                           <?php if($totalch) { ?><span><b>Total Chapter</b> <?php echo $totalch; ?></span><?php } ?>
											     <span><b>Total Volume</b> <?php echo meta(get_the_ID(),'east_totalvolume'); ?></span>
                           <span><b><?php _d('Released'); ?>:</b>  <?php echo meta(get_the_ID(),'east_date'); ?></span>
													 <span><b><?php _d('Years'); ?>:</b>  <?php echo term(get_the_ID(),'years'); ?></span>
                        </div>
                     </div>
                  </div>
               </div>
               <span itemprop="author" itemscope itemtype="https://schema.org/Person" class="author vcard"><i itemprop="name" content="<?php the_author(); ?>"></i></span>
               <time itemprop="datePublished" class="entry-date published" datetime="<?php the_time('c'); ?>"></time>
            </div>
            <?php east_alert_genre(get_the_ID()); ?>
						 <?php get_ads('adstoplsepisode','ads_lstepisode'); ?>
            <div class="whites lsteps widget_senction">
               <div class="animetitle-episode">
                  <span><?php _d('List Chapter');?> Manga <?php the_title(); ?></span>
               </div>
							 <div class="searcch"> <input type="text" id="searchchapter" onkeyup="searchlistchapt()" placeholder="Search by Chapter Ex: 99"></div>
               <?php EastManga::list_chapter(get_the_ID(), 1000);?>
            </div>
            <?php east_breadcrumbs_manga(get_the_ID()); endwhile; endif;
               if($recom == 1) { get_template_part('template/single/recom_manga'); }
               get_template_part('template/single/comments'); ?>
         </div>
         <?php get_template_part('sidebar','manga'); ?>
      </div>
   </div>
   </div>
</article>
<script type="text/javascript">
  $('#score_man').each(function(index, el) {
	  var $El = $(el);
	  $El.barrating({
	    theme: 'fontawesome-stars',
	    readonly: true,
	    initialRating: $El.attr('data-current-rating')
	  });
	});
</script>
<?php get_footer(); ?>

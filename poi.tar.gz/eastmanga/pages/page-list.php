<?php
/*
   Template Name: EasTheme - Manga List
*/

/* Exit if accessed directly */
if ( ! defined( 'ABSPATH' ) ) {
  exit;
}

$list = isset($_GET['list']);

get_header(); ?>
<div id="content" class="content-separate">
   <div id="primary" class="content-area">
      <main id="main" class="site-main post-body widget_senction" role="main">
         <div class="widget-title">
            <h1 class="page-title" itemprop="headline"><?php the_title(); ?></h1>
            <span class="filterss"><i class="fa fa-sort mr5"></i> <?php _d('Filter'); ?></span>
            <div class="mode_post">
               <?php if(!$list){ ?>
               <a href="<?php the_permalink(); ?>?list" class="enable"><i class="fas fa-list"></i></a>
               <a href="<?php the_permalink(); ?>"><i class="fas fa-th"></i></a>
               <?php } else { ?>
               <a href="<?php the_permalink(); ?>?list"><i class="fas fa-list"></i></a>
               <a href="<?php the_permalink(); ?>" class="enable"><i class="fas fa-th"></i></a>
               <?php } ?>
            </div>
         </div>
         <?php get_template_part('template/page/page','list'); ?>
      </main>
   </div>
   <?php sidebar_page(); ?>
</div>
<?php get_footer(); ?>

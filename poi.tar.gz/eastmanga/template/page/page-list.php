<?php
/*
* -------------------------------------------------------------------------------------
* @author: EasTheme Team
* @author URI: https://eastheme.com
* @copyright: (c) 2020 EasTheme. All rights reserved
* -------------------------------------------------------------------------------------
*
* @since 1.0.1
*
*/

/* Exit if accessed directly */
if ( ! defined( 'ABSPATH' ) ) {
  exit;
}

?>
<div class="filtersearch">
   <form action="<?php the_permalink(); ?>" method="GET">
      <table width="100%">
         <tbody>
           <tr>
              <td class="filter_title">Search</td>
              <td class="filter_act">
              <?php EastManga::form_search('title', 'Search...'); ?>
              </td>
           </tr>
            <tr>
               <td class="filter_title">Sort by</td>
               <td class="filter_act">
                  <ul class="filter-sort">
                     <?php
                        $array_order = array(
                          'title' => 'A-Z',
                          'titlereverse' => 'Z-A',
                          'update' => 'Latest Update',
                          'latest' => 'Latest Added',
                          'popular' => 'Popular'
                        );
                        EastManga::form_radio($array_order,'order',1); ?>
                  </ul>
               </td>
            </tr>
            <tr>
               <td class="filter_title">Status</td>
               <td class="filter_act">
                  <?php
                     $array_status = array(
                       'publishing' => 'Publishing',
                       'finished' => 'Finished'
                     );
                     EastManga::form_radio($array_status,'status',0); ?>
               </td>
            </tr>
            <tr>
               <td class="filter_title">Type</td>
               <td class="filter_act">
                  <?php
                     $array_type = array(
                      'Manga' => 'Manga',
                      'Manhwa' => 'Manhwa',
                      'Manhua' => 'Manhua',
                     );
                     EastManga::form_radio($array_type,'type',0); ?>
               </td>
            </tr>
            <tr class="filter_tax">
               <td class="filter_title">Genre</td>
               <td class="filter_act">
                  <?php EastManga::form_tax('genre','genre'); ?>
            </tr>
            <tr class="filter_tax">
               <td class="filter_title">Years</td>
               <td class="filter_act">
                  <?php EastManga::form_tax('years','years'); ?>
               </td>
            </tr>
         </tbody>
      </table>
      <div class="btnfilter"><button type="submit" class="filterbtn"><?php _d('Search'); ?></button></div>
   </form>
</div>
<?php if (!isset($_GET[ 'list'])) { EastManga::filter_search(); } else { EastManga::list('1000000'); } ?>

<script type="text/javascript">
$(document).ready(function () {
	$(".letr").click(function () {
		var href = $(this).attr('href');
		var res = href.replace("#", "");
		$(".listbar[name='" + res + "']").addClass('flashit');

		setTimeout(function () {
			$(".listbar[name='" + res + "']").removeClass("flashit");
		}, 1000);

		$('html, body').animate({
			scrollTop: $(".listbar[name='" + res + "']").offset().top - 70
		}, 100);
	});
});
</script>
<style>
.widget_senction .widget-title{margin-bottom: 0px}.relat {margin-top: 10px;}
</style>

<?php
/*
* -------------------------------------------------------------------------------------
* @author: EasTheme Team
* @author URI: https://eastheme.com
* @copyright: (c) 2020 EasTheme. All rights reserved
* -------------------------------------------------------------------------------------
*
* @since 1.0.1
*
*/

/* Exit if accessed directly */
if ( ! defined( 'ABSPATH' ) ) {
  exit;
}

$status = get_post_meta( get_the_ID(), 'east_status', true );
$type = get_post_meta( get_the_ID(), 'east_type', true );
$rating = get_post_meta( get_the_ID(), 'east_score', true );
$lastid = EastManga::latestchapter(get_the_ID());
?>
<article id="post-<?php the_ID(); ?>" <?php post_class(); ?> itemscope="itemscope" itemtype="http://schema.org/CreativeWork">
   <div class="animepost" id="post<?php the_id(); ?>">
      <div class="animposx">
            <div class="content-thumb">
						 <?php hot_label(get_the_ID()); ?>
             <div class="ply">
                 <div class="data">
                     <div class="profile_control animation-1">
                         <span><a href="<?php the_permalink(); ?>"><?php _d('View'); ?></a></span>
                         <span><a class="remove_favorites buttom-control-<?php the_id(); ?>" data-nonce="<?php echo wp_create_nonce('east_favorites_nonce'); ?>" data-postid="<?php the_id(); ?>"><?php _d('Remove'); ?></a></span>
                     </div>
                 </div>
             </div>
               <?php echo the_thumbnail(get_the_ID(), '200','160' ); ?>
               <div class="type <?php echo meta(get_the_ID(), 'east_type'); ?>"><?php echo meta(get_the_ID(), 'east_type'); ?></div>
               <div class="score"><i class="fa fa-star"></i> <?php echo meta(get_the_ID(), 'east_score'); ?></div>
            </div>
            <div class="data">
               <div class="title"> <?php the_title();?></div>
         </a>
         <?php if ($lastid) { foreach($lastid as $lastch) {?>
         <div class="char">
         <div class="plyepisode"><a href="<?php echo $lastch['permalink']; ?>"><i class="fas fa-book-open type-<?php echo $type; ?>"></i> Ch. <?php echo $lastch['chapter']; ?></a></div>
         <div class="chdt"><?php $time = $lastch['time']; if($time == 'new'){ echo '<div class="newchlabel">NEW</div>'; }else{ echo $time; } ?></div>
         </div>
         <?php } } else { ?>
         <div class="type"><?php echo status_manga(get_the_ID()); ?></div>
         <?php } ?>
         </div>
      </div>
   </div>
</article>

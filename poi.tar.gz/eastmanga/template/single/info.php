<?php
/*
* -------------------------------------------------------------------------------------
* @author: EasTheme Team
* @author URI: https://eastheme.com
* @copyright: (c) 2020 EasTheme. All rights reserved
* -------------------------------------------------------------------------------------
*
* @since 1.0.1
*
*/

/* Exit if accessed directly */
if ( ! defined( 'ABSPATH' ) ) {
  exit;
}

$series = get_post_meta(get_the_ID(), 'east_series', true);
?>
<div class="episodeinf widget_senction">
<div class="infoanime nocover">
  <div class="areainfo">
   <div class="thumb" itemprop="image" itemscope="" itemtype="https://schema.org/ImageObject">
      <?php echo the_thumbnail($series, '155','213' ); ?>
      <div class="rt">
         <?php east_favorites_button($series); ?>
      </div>
   </div>
   <div class="infox">
      <h2 class="entry-title" itemprop="partOfSeries"><i class="fas fa-book-open"></i> <?php echo get_the_title($series); ?></h2>
      <div class="desc">
         <div class="entry-content entry-content-single" itemprop="description">
            <?php $post = get_post($series);
            setup_postdata($post); echo get_the_content(); wp_reset_postdata(); ?>
         </div>
      </div>
      <div class="genre-info">
         <?php tax_genres($series); ?>
      </div>
   </div>
 </div>
</div>
</div>

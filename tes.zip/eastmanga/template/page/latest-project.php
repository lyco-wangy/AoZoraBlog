<?php
/*
* -------------------------------------------------------------------------------------
* @author: EasTheme Team
* @author URI: https://eastheme.com
* @copyright: (c) 2020 EasTheme. All rights reserved
* -------------------------------------------------------------------------------------
*
* @since 1.0.1
*
*/

/* Exit if accessed directly */
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

echo '<div class="post-show">';

$paged = (get_query_var('paged')) ? get_query_var('paged') : 1;
$showpost = get_option('updateproject');

if ($showpost == '') {
	$showpost = '8';
}

$myposts = array(
	'post_type' => 'manga',
	'orderby' => 'modified',
	'paged' => $paged,
  'meta_key' => 'east_project',
  'meta_value' => 1,
	'posts_per_page' => $showpost,
	'update_post_term_cache' => false,
	'update_post_meta_cache' => false,
	'cache_results' => false
);
$wp_query = new WP_Query($myposts);

while ($wp_query->have_posts()): $wp_query->the_post();

$lastid = EastManga::latestchapter(get_the_ID());
$type = meta(get_the_ID(),'east_type');
?>
<article id="post-<?php the_ID(); ?>" <?php post_class(); ?> itemscope="itemscope" itemtype="http://schema.org/CreativeWork">
   <div class="animepost">
      <div class="animposx">
         <a href="<?php the_permalink(); ?>"  alt="<?php the_title();?>" itemprop="url" rel="bookmark">
            <div class="content-thumb">
						 <?php hot_label(get_the_ID()); ?>
               <div class="ply">
                  <i class="fas fa-book-open"></i>
               </div>
               <?php echo the_thumbnail(get_the_ID(), '141','198' ); ?>
               <div class="type <?php echo $type; ?>"><?php echo $type; ?></div>
               <div class="score"><i class="fa fa-star"></i> <?php echo meta(get_the_ID(), 'east_score'); ?></div>
            </div>
            <div class="data">
               <div class="title"> <?php the_title();?></div>
         </a>
         <?php if ($lastid) { foreach($lastid as $lastch) {?>
         <div class="char">
         <div class="plyepisode"><a href="<?php echo $lastch['permalink']; ?>"><i class="fas fa-book-open type-<?php echo $type; ?>"></i> Ch. <?php echo $lastch['chapter']; ?></a></div>
         <div class="chdt"><?php $time = $lastch['time']; if($time == 'new'){ echo '<div class="newchlabel">NEW</div>'; }else{ echo $time; } ?></div>
         </div>
         <?php } } else { ?>
         <div class="type"><?php echo status_manga(get_the_ID()); ?></div>
         <?php } ?>
         </div>
      </div>
   </div>
</article>
<?php endwhile;
echo '</div>';
echo east_pagination();
wp_reset_query();

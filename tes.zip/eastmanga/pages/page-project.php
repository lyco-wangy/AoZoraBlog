<?php
/*
   Template Name: EasTheme - Latest Project
*/

/* Exit if accessed directly */
if ( ! defined( 'ABSPATH' ) ) {
  exit;
}

get_header(); ?>
<div id="content" class="content-separate">
   <div id="primary" class="content-area">
      <main id="main" class="site-main post-body widget_senction" role="main">
            <div class="widget-title">
                <h1 class="page-title" itemprop="headline"><?php the_title(); ?></h1>
            </div>
            <?php
           $lateststyle = get_option('latestupdatestyle');

           if($lateststyle == 2) {
            get_template_part('template/page/latest', 'project2');
          }else{
            get_template_part('template/page/latest', 'project');
          } ?>
         </main>
      </div>
      <?php sidebar_page(); ?>
</div>
<?php get_footer(); ?>
